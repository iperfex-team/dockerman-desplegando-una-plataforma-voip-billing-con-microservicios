
REQUIREMENTS
------------

- Apache2

- Asterisk >= version 1.2

- MySQL 5.x

- PHP >= version 5.3.0

- PHP MODULES :
    * PHP-PGSQL or PHP-MYSQLi
    * PHP-MCRYPT
    * PHP-XML
    * PHP_POSIX
    * PHP-GD
    * PHP-PCNTL
    * PHP-GETTEXT
    * PHP-SQLITE (only if you use the module to pool CDR)
    * PHP PEAR SOAP

- CallBack Module, Python requirements :
    * python >= version 2.6
    * python-mysqldb
    * python-psycopg2
    * python-sqlalchemy

- Monitoring IVR Module
    * Cepstral Text to speech (http://www.cepstral.com)
